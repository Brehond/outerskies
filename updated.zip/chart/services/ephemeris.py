import swisseph as swe
from datetime import datetime
import os

# Automatically set the path to the ephemeris data folder relative to this file
EPHEMERIS_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'ephemeris'))
swe.set_ephe_path(EPHEMERIS_PATH)

# Supported planets for prompt templates
PLANETS = {
    "Sun": swe.SUN, "Moon": swe.MOON, "Mercury": swe.MERCURY,
    "Venus": swe.VENUS, "Mars": swe.MARS, "Jupiter": swe.JUPITER,
    "Saturn": swe.SATURN, "Uranus": swe.URANUS, "Neptune": swe.NEPTUNE, "Pluto": swe.PLUTO
}

def get_julian_day(date_str: str, time_str: str) -> float:
    dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    return swe.julday(dt.year, dt.month, dt.day, dt.hour + dt.minute / 60.0)

def get_planet_positions(jd: float) -> dict:
    return {planet: swe.calc_ut(jd, code)[0][0] for planet, code in PLANETS.items()}
