from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from chart.services import ephemeris
from ai_integration import openrouter_api
from chart.prompts import PLANET_TEMPLATES, CHART_TEMPLATES

def chart_form(request):
    return render(request, "chart_form.html")

@csrf_exempt
def generate_chart(request):
    date = request.GET.get("date")
    time = request.GET.get("time")
    lat = request.GET.get("lat")
    lon = request.GET.get("lon")
    location = request.GET.get("location", "")

    jd = ephemeris.get_julian_day(date, time)
    positions = ephemeris.get_planet_positions(jd)

    # Individual planetary interpretations
    planet_results = {}
    for planet, pos in positions.items():
        prompt_template = PLANET_TEMPLATES.get(planet)
        if not prompt_template:
            continue
        prompt = prompt_template.format(
            date=date, time=time, location=location, position=pos
        )
        interpretation = openrouter_api.generate_interpretation(prompt)
        planet_results[planet] = {
            "position": round(pos, 2),
            "interpretation": interpretation
        }

    # Full chart reading with the "master" template
    master_prompt = CHART_TEMPLATES.get("master")
    if master_prompt:
        master_prompt_filled = master_prompt.format(
            date=date, time=time, location=location,
            positions=", ".join([f"{k}: {v:.2f}" for k, v in positions.items()])
        )
        chart_summary = openrouter_api.generate_interpretation(master_prompt_filled)
    else:
        chart_summary = None

    return JsonResponse({
        "julian_day": jd,
        "chart": planet_results,
        "chart_summary": chart_summary
    })
