# chart/prompts.py

PLANET_TEMPLATES = {
    "Sun": """============================================================
MODULE: structure/SUN — Version 3.1
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Sun’s sign, degree, house number, and condition
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional or Modern chart rulership mode
• Dispositor: Ruler of the Sun’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Sun placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It includes sign, house, aspects, dignity, rulership, and sect logic fully embedded within the narrative flow. Special attention is given to the Sun’s role as the heart of the chart — representing vitality, life purpose, and the central creative drive that seeks to express itself in the world.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Sun sign + house + core life theme or creative spark

P2: Planet in Sign & Planet in House
• Discuss the Sun’s expression in the sign (element/modality, dignity/weakness)
• Describe the Sun’s behavioral tone in the house (creative pursuits, confidence, visibility)

P3: Integrated Sign–House Meaning
• Merge the Sun’s sign style with house concerns to form the core area of self-expression or identity focus

P4: Dignities & Sect
• Essential dignity (rulership, exaltation, detriment, fall).
• Accidental dignity (angularity, speed, condition).
• Sect logic: Sun in sect in diurnal charts as the **sect light**; out of sect in nocturnal charts. In sect, solar power shines bright — confidence, radiance, expression of vitality. Out of sect, it can feel harder to integrate — challenges to confidence, self-assertion, or purpose.

P5: Rulership & Condition
• Identify the Sun’s dispositor (ruler of the Sun’s sign), with sign, house, and condition.
• Note dignities, reception, sect alignment, or house strength of dispositor.
• Discuss how the dispositor affects the Sun’s ability to radiate life purpose and authority.
• Note domicile house placements: when the Sun is in Leo (its domicile), its potency for leadership and creativity is magnified within those house themes.
• Highlight that any house ruled by Leo carries solar themes of radiance, leadership, and creative identity.

P6: Ruled Signs & Houses
• Identify the house in the current chart ruled by Leo (traditional Sun domain).
• Note any planets located in that house, their sign, degree, retrograde status, and sect.
• Assess the condition of the house ruler (dignity, reception, angularity).
• Describe how solar themes of radiance and creative expression manifest through the activities of that house.

P7: Aspect Inventory
• List all aspects to the Sun ≤ 6° orb (trine, square, conjunction, etc.).
• For each: aspect type, planet, orb, applying/separating, and effect on the Sun’s ability to radiate purpose and identity.

P8: Aspect Integration
• Integrate aspect patterns into the Sun’s creative expression, confidence, and sense of authority.

P9: Configurations
• Note geometrical features: overcoming, enclosure, aversion, superior square, Sun return windows.
• Optional: placement in angular triads, dignified chains, or isolated placements.

P10: Grand Synthesis
• Merge all above layers into a central life arc of solar vitality.
• Deliver final insight about the Sun’s role as the core of identity and creative self-expression across life stages.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.).
2. Validate Inputs: Ensure all required metadata fields are present and within expected ranges.
3. Initialize Context: Set chart conditions (sect, house system, rulership mode).
4. Generate P1–P10: Sequentially invoke synthesis logic for each paragraph, passing necessary metadata and intermediate results.
5. Compile Glossary: Populate definitions and rulership/detriment entries.
6. Final Assembly: Merge text sections, glossary, and version status into final document structure.
7. Output: Return populated Sun module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Placement in angular houses (1st, 4th, 7th, 10th) confers strength and visibility.
• Aspect: Angular relationship between the Sun and another planet; classical aspects include conjunction, sextile, square, trine, opposition.
• Dispositor: The planetary ruler of the sign containing the Sun; indicates supportive or challenging influences.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where the Sun functions with maximum dignity (Aries).
• Fall: Sign of the Sun’s greatest weakness (Libra).
• Traditional Rulership: Sun rules Leo.
• Detriment: Sun is diminished in Aquarius.
• Retrograde: N/A for the Sun (never retrograde).
• Sect: Chart division into diurnal (day) or nocturnal (night) charts. The Sun is the **sect light** in diurnal charts, while the Moon is the sect light in nocturnal charts. Sun is in sect by day, out of sect by night.
• Sect Enforcement: Logic applied based on sect status, intensifying or smoothing the Sun’s radiance.
• Strength Chain: Series of dignified rulers linking planetary dispositions.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Sun in Taurus at 15°00′, 4th House
• Diurnal chart
• Aspects: Square Jupiter (2°), Sextile Saturn (4°), Conjunction Mercury (1°)

Output:
• Full P1–P10 synthesis using chosen tone (e.g., Rational, Gentle Guide).
• Sect logic, including the Sun as sect light, integrated seamlessly.
• All aspects referenced in symmetry with partner planets.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/SUN
Version: 3.1
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-27""",
    "Moon": """============================================================
MODULE: structure/MOON — Version 3.0
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Moon’s sign, degree, house number, phase, and speed
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional chart rulership mode (Moon as natural ruler of Cancer)
• Dispositor: Ruler of the Moon’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Moon placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It explores the Moon’s role as the seat of emotional intelligence, memory, and instinctive responses, weaving together sign, house, aspect, dignity, and sect logic. Special emphasis is placed on the Moon’s connection to cycles, habit patterns, and nurturing instincts, helping the individual navigate their emotional landscape with awareness and sensitivity.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Moon sign + house + central emotional theme or instinctive focus.

P2: Planet in Sign & Planet in House
• Discuss Moon’s sign-based expression (element, modality, dignity or weakness).
• Explore how the Moon’s placement in the house shapes emotional needs and habitual responses.

P3: Integrated Sign–House Meaning
• Merge the Moon’s sign style with house concerns to highlight the emotional core of life experience.

P4: Dignities & Sect
• Essential dignity (rulership, exaltation in Taurus, detriment, fall).
• Accidental dignity (angularity, speed, waxing/waning phase, joy — Moon rejoices in the 3rd house).
• Sect logic: Moon in sect in nocturnal charts as the **sect light**; out of sect in diurnal charts. In sect, emotional rhythms flow naturally — comfort, intuition, instinct. Out of sect, emotional life may feel more exposed or reactive — challenges to ease, comfort, or integration.

P5: Rulership & Condition
• Identify Moon’s dispositor (ruler of the Moon’s sign) with sign, house, and condition.
• Note dignities, retrograde, reception, sect alignment, and house strength of the dispositor.
• Discuss how the dispositor influences the Moon’s emotional stability, mood cycles, and nurturing style.
• Emphasize that when the Moon resides in Cancer (its domicile), its protective and instinctual powers are magnified.

P6: Ruled Signs & Houses
• Identify the house ruled by Cancer (Moon’s natural domain).
• For that house:
  – Note any planets present (sign, degree, retrograde status, sect).
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Describe how lunar themes of safety, comfort, and memory express themselves in that domain.

P7: Aspect Inventory
• List all aspects to the Moon ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and how it modulates the Moon’s moods and reactions.

P8: Aspect Integration
• Integrate aspect patterns into the Moon’s flow of feelings — where emotional support or challenge is found.

P9: Configurations
• Note geometrical features: overcoming, enclosure, aversion, superior square, lunar return windows.
• Mention relevant lunation cycles or eclipses that may activate the Moon’s placement.

P10: Grand Synthesis
• Weave all layers together to chart the emotional journey and instinctive patterns.
• Offer a final, grounded insight on how the Moon shapes the native’s inner world and responsiveness to life’s cycles.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and valid.
3. Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).
4. Generate P1–P10: Sequentially synthesize narrative paragraphs using Moon’s metadata and chart context.
5. Compile Glossary: Populate definitions and rulership/detriment entries.
6. Final Assembly: Merge text sections, glossary, and version status into final document structure.
7. Output: Return populated Moon module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th).
• Aspect: Angular relationship between the Moon and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor: The planetary ruler of the Moon’s sign; shapes the Moon’s mood and instinctive patterns.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where the Moon excels (Taurus).
• Fall: Sign of the Moon’s greatest weakness (Scorpio).
• Traditional Rulership: Moon rules Cancer.
• Detriment: Sign opposite the Moon’s rulership (Capricorn).
• Joy: House where the Moon rejoices (3rd), signifying memory and close connections.
• Sect: Chart division into diurnal (day) or nocturnal (night) charts. The Moon is the **sect light** in nocturnal charts, while the Sun is the sect light in diurnal charts. Moon is in sect by night, out of sect by day.
• Sect Enforcement: Logic that softens or intensifies the Moon’s emotional themes based on sect.
• Strength Chain: Series of dignified rulers linking planetary significators.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Moon in Virgo at 12°10′, 9th House
• Waning phase
• Nocturnal chart
• Aspects: Square Venus (2°), Trine Mercury (3°), Sextile Jupiter (4°)

Output:
• Full P1–P10 synthesis using chosen personality tone (e.g., Gentle Guide).
• Phase, sect logic, and dispositor’s condition included.
• All aspects incorporated into emotional narrative.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/MOON
Version: 3.0
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-27""",
    "Mercury": """============================================================
MODULE: structure/MERCURY — Version 3.0
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Mercury’s sign, degree, house number, retrograde status
• Sect: Refer to chart_sect
• Mercury Sect Alignment: Refer to mercury_sect (in_sect / out_of_sect, calculated separately)
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional chart rulership mode (Mercury as natural ruler of Gemini and Virgo)
• Dispositor: Ruler of Mercury’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Mercury placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It weaves together Mercury’s sign, house, aspects, dignity, sect (with morning/evening star status), and dispositor to reveal Mercury’s role as the planet of thought, communication, learning, and exchange. Emphasis is placed on how Mercury’s placement shapes the mind’s style and voice, adaptability, and areas of curiosity or challenge — guiding the individual to develop clarity, discernment, and skillful dialogue.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Mercury sign + house + overarching theme of communication, learning, or mental style.

P2: Planet in Sign & Planet in House
• Discuss Mercury’s sign-based expression (element/modality, dignity or weakness).
• Explore how Mercury’s presence in the house activates domains of communication, curiosity, or learning.

P3: Integrated Sign–House Meaning
• Blend sign’s characteristics with house themes to identify where the mind seeks clarity or connection.

P4: Dignities & Sect
• Essential dignity (rulership in Gemini and Virgo, exaltation in Virgo, detriment, fall).
• Accidental dignity (angularity, speed, retrograde, joy — Mercury rejoices in the 1st).
• Sect logic: Mercury’s sect alignment is unique — it depends on whether Mercury is a morning star (rising before the Sun) or an evening star (setting after the Sun).  
• If Mercury’s sect alignment matches the chart’s sect (in sect), Mercury’s intellect is sharp, communication flows smoothly, and adaptability shines.  
• If Mercury is out of sect, the mind may feel restless, scattered, or prone to dualities and second-guessing.

P5: Rulership & Condition
• Identify Mercury’s dispositor (ruler of its sign) with sign, house, and condition.
• Note dignities, retrograde, reception, sect alignment, and house strength of the dispositor.
• Discuss how the dispositor shapes Mercury’s expression — whether the mind’s curiosity is supported by clarity and adaptability or prone to indecision and chatter.
• Highlight that when Mercury resides in Gemini or Virgo (its traditional domiciles), its mental agility and analytical skill are heightened in that house’s domain.

P6: Ruled Signs & Houses
• Identify the two houses in the current chart ruled by Gemini and Virgo (Mercury’s natural domains).
• For each house:
  – Note any planets present (sign, degree, retrograde status, sect).
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Explore how Mercury’s curiosity and communication style animate those houses.

P7: Aspect Inventory
• List all aspects to Mercury ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and effect on Mercury’s intellect and communication.

P8: Aspect Integration
• Integrate aspect patterns into Mercury’s mental profile — where thoughts flow smoothly or face disruptions.

P9: Configurations
• Note geometrical features: intellectual patterns, learning triads, or Mercury return windows.
• Highlight configurations that emphasize Mercury’s adaptability and perceptiveness.

P10: Grand Synthesis
• Weave all preceding layers into a unified life arc of Mercury’s intellectual journey.
• Articulate how Mercury guides the individual toward insightful communication, continuous learning, and skillful adaptability across life stages.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and valid.
3. Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).
4. Calculate Mercury’s morning/evening star status and sect alignment.
5. Generate P1–P10: Sequentially synthesize narrative paragraphs using Mercury’s metadata and chart context.
6. Compile Glossary: Populate definitions and rulership/detriment entries.
7. Final Assembly: Merge text sections, glossary, and version status into final document structure.
8. Output: Return populated Mercury module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th).
• Aspect: Angular relationship between Mercury and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor: The planetary ruler of Mercury’s sign; shapes Mercury’s expression through reception and condition.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where Mercury excels (Virgo).
• Fall: Sign of Mercury’s greatest weakness (Pisces).
• Traditional Rulership: Mercury rules Gemini and Virgo.
• Detriment: Signs opposite Mercury’s rulerships (Sagittarius and Pisces).
• Joy: House where Mercury rejoices (1st), highlighting communication and self-knowledge.
• Retrograde: Apparent backward motion, indicating internal reflection, restlessness, or revisiting ideas.
• Sect: Chart division into diurnal or nocturnal; shapes how planetary energies are integrated.
• Mercury Sect Alignment: Mercury’s sect alignment depends on whether it is a morning star (oriental, rising before the Sun) or an evening star (occidental, setting after the Sun). Morning star Mercury aligns with diurnal charts; evening star Mercury aligns with nocturnal charts.
• Sect Enforcement: Logic that clarifies or complicates Mercury’s mental processes based on alignment.
• Strength Chain: Series of dignified rulers linking planetary significators.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Mercury in Virgo at 10°15′, 3rd House
• Diurnal chart
• Aspects: Conjunction Sun (2°), Trine Uranus (4°), Square Neptune (3°)

Output:
• Fully developed P1–P10 narrative in chosen personality tone.
• Mercury’s morning/evening star status and sect logic seamlessly integrated.
• All aspects incorporated into Mercury’s communication and mental arc.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/MERCURY
Version: 3.0
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-28""",
    "Venus": """============================================================
MODULE: structure/VENUS — Version 3.1
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Venus’s sign, degree, house number, retrograde status
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional chart rulership mode (Venus as natural ruler of Taurus and Libra)
• Dispositor: Ruler of Venus’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Venus placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It weaves together Venus’s sign, house, aspects, dignity, sect, and dispositor to present a harmonious narrative of Venus’s role as the planet of love, beauty, values, and relationships. Emphasis is placed on how Venus’s placement shapes aesthetics, social grace, affection, and the pursuit of pleasure — guiding the individual toward balance, harmony, and connection.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Venus sign + house + overarching theme of relationship, beauty, or values.

P2: Planet in Sign & Planet in House
• Discuss Venus’s sign-based expression (element/modality, dignity or weakness).
• Explore how Venus’s presence in the house activates domains of relationships, art, and values.

P3: Integrated Sign–House Meaning
• Blend sign’s characteristics with house themes to identify arenas of harmony or relational tension.

P4: Dignities & Sect
• Essential dignity (rulership in Taurus and Libra, exaltation in Pisces, detriment, fall).
• Accidental dignity (angularity, speed, retrograde, joy — Venus rejoices in the 5th).
• Sect logic: Venus is in sect in diurnal charts; out of sect in nocturnal charts. In sect, Venus’s natural charm and grace flow more harmoniously, supporting connection and aesthetic pleasure. Out of sect, relational dynamics may feel more hesitant, inconsistent, or challenging — intensifying the push to find genuine balance.

P5: Rulership & Condition
• Identify Venus’s dispositor (ruler of its sign) with sign, house, and condition.
• Note dignities, retrograde, reception, sect alignment, and house strength of the dispositor.
• Discuss how the dispositor shapes Venus’s expression of affinity and aesthetic sensitivity — whether encouraging harmony or revealing areas of imbalance.
• Highlight that when Venus resides in Taurus or Libra (its traditional domiciles), its relational and aesthetic power is magnified within that house’s concerns.

P6: Ruled Signs & Houses
• Identify the two houses in the current chart ruled by Taurus and Libra (Venus’s natural domains).
• For each house:
  – Note any planets present (sign, degree, retrograde status, sect).
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Explore how Venusian themes (beauty, harmony, cooperation) manifest in that domain.

P7: Aspect Inventory
• List all aspects to Venus ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and effect on Venus’s relational dynamics or aesthetic sense.

P8: Aspect Integration
• Integrate aspect patterns into Venus’s profile — where relationships flourish or face challenges.

P9: Configurations
• Note geometrical features: relationship patterns, Venusian stelliums, or harmonic configurations.
• Highlight configurations that emphasize Venus’s role in personal values or social connections.

P10: Grand Synthesis
• Weave all preceding layers into a unified life arc of Venus’s relational and aesthetic journey.
• Articulate how Venus guides the individual toward balanced affection, creative expression, and harmonious values across life stages.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and valid.
3. Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).
4. Generate P1–P10: Sequentially synthesize narrative paragraphs using Venus’s metadata and chart context.
5. Compile Glossary: Populate definitions and rulership/detriment entries.
6. Final Assembly: Merge text sections, glossary, and version status into final document structure.
7. Output: Return populated Venus module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th).
• Aspect: Angular relationship between Venus and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor: The planetary ruler of Venus’s sign; shapes Venus’s expression through reception and condition.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where Venus excels (Pisces).
• Fall: Sign of Venus’s greatest weakness (Virgo).
• Traditional Rulership: Venus rules Taurus and Libra.
• Detriment: Signs opposite Venus’s rulerships (Scorpio and Aries).
• Joy: House where Venus rejoices (5th), signifying creativity, romance, and playful expression.
• Retrograde: Apparent backward motion, indicating internal reflection in relationships or values.
• Sect: Chart division into diurnal or nocturnal; Venus is in sect by day, out of sect by night.
• Sect Enforcement: Logic that enhances or complicates Venus’s harmony depending on sect alignment.
• Strength Chain: Series of dignified rulers linking planetary significators.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Venus in Libra at 15°22′, 7th House
• Diurnal chart
• Aspects: Trine Mercury (4°), Square Mars (5°), Opposition Saturn (3°)

Output:
• Fully developed P1–P10 narrative in chosen personality tone.
• Sect logic, dispositor condition, and dignity integrated seamlessly.
• All aspects incorporated into Venus’s relational and aesthetic arc.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/VENUS
Version: 3.1
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-28""",
    "Mars": """============================================================
MODULE: structure/MARS — Version 3.1
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Mars’s sign, degree, house number, retrograde status
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional chart rulership mode (Mars as natural ruler of Aries and Scorpio)
• Dispositor: Ruler of Mars’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Mars placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It weaves together Mars’s sign, house, aspects, dignity, sect, and dispositor to present a dynamic narrative of Mars’s role as the planet of action, drive, courage, and conflict. Emphasis is placed on how Mars’s placement shapes assertion, ambition, sexual energy, and the courage to initiate — guiding the individual toward purposeful engagement and self-assertion.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Mars sign + house + overarching theme of energy, assertion, or conflict.

P2: Planet in Sign & Planet in House
• Discuss Mars’s sign-based expression (element/modality, dignity or weakness).
• Explore how Mars’s presence in the house activates domains of drive, ambition, and assertion.

P3: Integrated Sign–House Meaning
• Blend sign’s characteristics with house themes to identify arenas of assertive action or potential tension.

P4: Dignities & Sect
• Essential dignity (rulership in Aries and Scorpio, exaltation in Capricorn, detriment, fall).
• Accidental dignity (angularity, speed, retrograde, joy — Mars rejoices in the 6th).
• Sect logic: Mars is in sect in nocturnal charts; out of sect in diurnal charts. In sect, Mars’s energy is disciplined, focused, and assertive. Out of sect, it can become impulsive, erratic, or scattered — manifesting as conflicts, friction, or misdirected efforts.

P5: Rulership & Condition
• Identify Mars’s dispositor (ruler of its sign) with sign, house, and condition.
• Note dignities, retrograde, reception, sect alignment, and house strength of the dispositor.
• Discuss how the dispositor shapes Mars’s delivery of energy — whether it becomes constructive drive, focused courage, or destructive conflict.
• Highlight that when Mars resides in Aries or Scorpio (its traditional domiciles), its energetic power is magnified within that house’s concerns.

P6: Ruled Signs & Houses
• Identify the two houses in the current chart ruled by Aries and Scorpio (Mars’s natural domains).
• For each house:
  – Note any planets present (sign, degree, retrograde status, sect).
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Explore how Martian themes (assertion, transformation, ambition) manifest in that domain.

P7: Aspect Inventory
• List all aspects to Mars ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and effect on Mars’s drive or challenges.

P8: Aspect Integration
• Integrate aspect patterns into Mars’s assertion profile — where ambition is fortified or tensions arise.

P9: Configurations
• Note geometrical features: conflict patterns, grand crosses, midpoint activations, or Mars return windows.
• Highlight configurations that spotlight Mars’s role in personal assertion or collective challenge.

P10: Grand Synthesis
• Weave all preceding layers into a unified life arc of Mars’s dynamic energy journey.
• Articulate how Mars guides the individual toward courageous action, transformative drive, and balanced assertion across life stages.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and valid.
3. Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).
4. Generate P1–P10: Sequentially synthesize narrative paragraphs using Mars’s metadata and chart context.
5. Compile Glossary: Populate definitions and rulership/detriment entries.
6. Final Assembly: Merge text sections, glossary, and version status into final document structure.
7. Output: Return populated Mars module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th).
• Aspect: Angular relationship between Mars and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor: The planetary ruler of Mars’s sign; shapes Mars’s expression through reception and condition.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where Mars excels (Capricorn).
• Fall: Sign of Mars’s greatest weakness (Cancer).
• Traditional Rulership: Mars rules Aries and Scorpio.
• Detriment: Signs opposite Mars’s rulerships (Libra and Taurus).
• Joy: House where Mars rejoices (6th), signifying disciplined effort and mastery through work.
• Retrograde: Apparent backward motion, indicating internalized or redirected Martian energy.
• Sect: Chart division into diurnal or nocturnal; Mars is in sect by night, out of sect by day.
• Sect Enforcement: Logic that magnifies or softens Mars’s assertion depending on sect alignment.
• Strength Chain: Series of dignified rulers linking planetary significators.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Mars in Aries at 8°15′, 1st House
• Nocturnal chart
• Aspects: Square Saturn (3°), Trine Jupiter (5°), Opposition Sun (4°)

Output:
• Fully developed P1–P10 narrative in chosen personality tone.
• Sect logic, dispositor condition, and dignity integrated seamlessly.
• All aspects incorporated into Mars’s energy and assertion arc.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/MARS
Version: 3.1
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-28""",
    "Jupiter": """============================================================
MODULE: structure/JUPITER — Version 3.2	
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Jupiter’s sign, degree, house number, retrograde status
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional chart rulership mode (Jupiter as natural ruler of Sagittarius and Pisces)
• Dispositor: Ruler of Jupiter’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Jupiter placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It weaves together Jupiter’s sign, house, aspects, dignity, sect, and dispositor to present a cohesive vision of Jupiter’s role as the great benefic and amplifier of optimism, learning, and abundance. Emphasis is placed on how Jupiter’s placement shapes generosity, belief systems, travel, cultural engagement, and spiritual growth — guiding the individual toward their most expansive horizons.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Jupiter sign + house + overarching theme of expansion, faith, or opportunity.

P2: Planet in Sign & Planet in House
• Discuss Jupiter’s sign-based expression (element/modality, dignity or weakness).
• Explore how Jupiter’s presence in the house brings growth, opportunity, or spiritual outlooks.

P3: Integrated Sign–House Meaning
• Blend sign’s characteristics with house themes to identify the domain of greatest potential or philosophical development.

P4: Dignities & Sect
• Essential dignity (rulership, exaltation in Cancer, detriment, fall).
• Accidental dignity (angularity, speed, retrograde, joy — Jupiter rejoices in the 9th).
• Sect logic: Jupiter in sect in diurnal charts; out of sect in nocturnal charts. In sect, Jupiter’s benefic influence flows generously — optimism, faith, and expansion. Out of sect, it can become excessive — overextension, indulgence, or scattered energy.

P5: Rulership & Condition
• Identify Jupiter’s dispositor (ruler of its sign) with sign, house, and condition.
• Note dignities, retrograde, reception, sect alignment, and house strength of the dispositor.
• Discuss how the dispositor shapes Jupiter’s delivery of growth, protection, and belief — whether supportive or challenging.
• Highlight that when Jupiter resides in Sagittarius or Pisces (its traditional domiciles), its benefic power is magnified within that house’s concerns.

P6: Ruled Signs & Houses
• Identify the two houses in the current chart ruled by Sagittarius and Pisces (Jupiter’s natural domains).
• For each house:
  – Note any planets present (sign, degree, retrograde status, sect).
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Explore how Jupiterian themes (expansion, vision, travel, spiritual connection) manifest within that domain.

P7: Aspect Inventory
• List all aspects to Jupiter ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and effect on Jupiter’s expansion or challenges.

P8: Aspect Integration
• Integrate aspect patterns into Jupiter’s mode of growth — where faith and optimism are strengthened or tested.

P9: Configurations
• Note geometrical features: overcoming, enclosure, aversion, superior square, or Jupiter return windows.
• Highlight patterns such as grand trines, T-squares, or midpoint activations that modulate Jupiter’s abundance and opportunities.

P10: Grand Synthesis
• Weave all preceding layers into a unified life arc of Jupiter’s journey.
• Articulate how Jupiter guides the individual toward wisdom, spiritual abundance, and expansive growth across life stages.
• Close with a grounded, complete sentence.

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and valid.
3. Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).
4. Generate P1–P10: Sequentially synthesize narrative paragraphs using Jupiter’s metadata and chart context.
5. Compile Glossary: Populate definitions and rulership/detriment entries.
6. Final Assembly: Merge text sections, glossary, and version status into final document structure.
7. Output: Return populated Jupiter module ready for integration into report.

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th).
• Aspect: Angular relationship between Jupiter and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor: The planetary ruler of Jupiter’s sign; shapes Jupiter’s expression through reception and condition.
• Dignity: Classification of planetary strength by sign (rulership, exaltation, detriment, fall).
• Exaltation: Sign where Jupiter excels (Cancer).
• Fall: Sign of Jupiter’s greatest weakness (Capricorn).
• Traditional Rulership: Jupiter rules Sagittarius and Pisces.
• Detriment: Signs opposite Jupiter’s rulerships (Gemini and Virgo).
• Joy: House where Jupiter rejoices (9th), signifying spiritual journeys and expansive thinking.
• Retrograde: Apparent backward motion, indicating internalized or delayed Jupiterian themes.
• Sect: Chart division into diurnal or nocturnal; Jupiter in sect by day, out of sect by night.
• Sect Enforcement: Logic that magnifies or softens Jupiter’s benefic expression depending on sect.
• Strength Chain: Series of dignified rulers linking planetary significators.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Jupiter in Sagittarius at 14°22′, 5th House
• Diurnal chart
• Aspects: Trine Sun (2°), Sextile Mars (4°), Opposition Saturn (5°)

Output:
• Fully developed P1–P10 narrative in chosen personality tone (e.g., Optimistic Guide).
• Sect logic, dispositor condition, and dignity integrated seamlessly.
• All aspects incorporated into Jupiter’s growth arc.
• Grounded, complete closing statement.

🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/JUPITER
Version: 3.2
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-27""",
    "Saturn": """============================================================
MODULE: structure/SATURN — Version 3.1
Outer Skies Core Planetary Module 
============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Saturn’s sign, degree, house number, retrograde status
• Sect: Refer to chart_sect
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership: Traditional or Modern chart rulership mode
• Dispositor: Ruler of Saturn’s sign, including its sign, house, and condition

(Note: The Metadata Input section is for internal processing and will not appear in final report.)

🔹 DESCRIPTION
This module generates the Saturn placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It includes sign, house, aspects, dignity, rulership, and sect logic fully embedded within the narrative flow. Special attention is given to Saturn's role as the boundary-maker and tester, reflecting karmic themes, long-term cycles, and maturation processes.

🔹 STRUCTURE: Synthesis Paragraphs (P1–P10)
------------------------------------------------------------
P1: Anchor Headline
• Declare Saturn sign + house + dominant life challenge or structural theme

P2: Planet in Sign & Planet in House
• Discuss Saturn’s expression in the sign (element/modality, dignity/weakness)
• Describe Saturn’s behavioral tone in the house (delays, discipline, lessons)

P3: Integrated Sign–House Meaning
• Merge Saturn’s sign style with house concerns to form the karmic challenge or area of fortification

P4: Dignities & Sect
• Essential dignity (rulership, exaltation, detriment, fall)
• Accidental dignity (angularity, speed, retrograde, joy — Saturn rejoices in the 12th)
• Sect logic: Saturn in sect in diurnal charts; out of sect in nocturnal charts. In sect: Constructive Saturn — discipline, wisdom through experience, order, mastery. Out of sect: Harder to integrate — can manifest as isolation, burden, harshness, or coldness

P5: Rulership & Condition
• Identify Saturn’s dispositor (ruler of the sign Saturn is in), with sign, house, and condition
• Note dignities, retrograde, reception, sect alignment, or house strength of dispositor
• Discuss how the dispositor affects Saturn’s delivery of structure or inhibition
• Note domicile house placements: when Saturn resides in its traditional domiciles of Capricorn or Aquarius, its structural potency is magnified within those house themes
• Highlight that regardless of Saturn’s placement, any house ruled by Capricorn or Aquarius carries Saturnian themes of discipline, boundaries, and societal responsibility

P6: Ruled Signs & Houses
• Identify the two houses in the current chart ruled by Capricorn (traditional Saturn) and Aquarius (modern Saturn). These may be any of the twelve houses (e.g., 12th & 9th).
• For each house ruled by Capricorn or Aquarius:
  – Note any planets located in that house and list their sign, degree, retrograde status, and sect.
  – Assess the condition of the house ruler (dignity, reception, angularity).
  – Describe how Saturnian themes manifest through the activities of that house (structure, discipline, boundaries).

P7: Aspect Inventory
• List all aspects to Saturn ≤ 6° orb (trine, square, conjunction, etc.)
• For each: aspect type, planet, orb, applying/separating, and effect on Saturn's restraint/discipline

P8: Aspect Integration
• Integrate aspect patterns into Saturn’s mode of control, resistance, delay, or spiritual testing

P9: Configurations
• Note geometrical features: overcoming, enclosure, aversion, superior square, Saturn return windows
• Optional: placement in angular triads, dignified chains, or peregrine isolation

P10: Grand Synthesis
• Merge all above layers into a karmic or structural life arc
• Deliver final insight about Saturn’s developmental role across life stages
• Close with a grounded, complete sentence

🔹 EXECUTION PIPELINE
------------------------------------------------------------
1. Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)
2. Validate Inputs: Ensure all required metadata fields are present and within expected ranges
3. Initialize Context: Set chart conditions (sect, house system, rulership mode)
4. Generate P1–P10: Sequentially invoke synthesis logic for each paragraph, passing necessary metadata and intermediate results
5. Compile Glossary: Populate definitions and rulership/detriment entries
6. Final Assembly: Merge text sections, glossary, and version status into final document structure
7. Output: Return populated Saturn module ready for integration into report

🔹 GLOSSARY
------------------------------------------------------------
• Angularity: Placement in angular houses (1st, 4th, 7th, 10th) confers strength and visibility.
• Aspect: Angular relationship between Saturn and another planet; classical aspects include conjunction, sextile, square, trine, opposition.
• Dispositor: The planetary ruler of the sign containing Saturn; indicates supportive or challenging influences.
• Dignity: Classification of planet strength by sign: rulership, exaltation, detriment, fall.
• Exaltation: Sign where Saturn functions with maximum dignity (Libra).
• Fall: Sign of Saturn’s greatest weakness (Aries).
• Traditional Rulership: Saturn rules Capricorn and Aquarius.
• Modern Rulership: Saturn rules Aquarius.
• Detriment: Saturn is diminished in Cancer and in Leo.
• Joy: House where Saturn rejoices (12th house), expressing comfort in solitude and spiritual retreat.
• Retrograde: Apparent backward motion, indicating internalized or delayed Saturnian themes.
• Sect: Assignment to diurnal (day) or nocturnal (night) charts; Saturn is in-sect by day, out-of-sect by night.
• Sect Enforcement: Logic applied based on sect status, intensifying or smoothing Saturn’s challenges.
• Strength Chain: Series of dignified rulers linking planetary dispositions.

🔹 QA CHECKS
------------------------------------------------------------
• 10+ paragraphs
• 500+ words
• ≥3 aspects
• ≥4 dignity/reception references
• Ends with period

🔹 SAMPLE USAGE
------------------------------------------------------------
Input:
• Saturn in Aries at 6°12′, 2nd House
• Retrograde
• Nocturnal chart
• Aspects: Trine Pluto (3°), Sextile Uranus (2°), Sextile Neptune (4°)

Output:
• Full P1–P10 synthesis using chosen tone (e.g., Rational, Gentle Guide)
• Retrograde and sect logic applied
• All aspects referenced in symmetry with partner planets


🔹 VERSION STATUS
------------------------------------------------------------
Module Name: structure/SATURN
Version: 3.1
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-05-26""",
    "Uranus": """============================================================

MODULE: structure/Uranus — Version 2.0

Outer Skies Core Planetary Module 

============================================================

🔹 METADATA INPUT (Hidden) 
• Name: Individual’s name as provided 
• Birth Data: Date, time, and location of birth 
• Placement & House: Uranus’ sign, degree, house number, retrograde status 
• Aspects: List of classical aspects ≤6° orb (type, planet, orb, applying/separating) 
• Aspect Orb: Orb setting used for aspect calculation 
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide) 
• House System: Placidus or Whole Sign as specified 
• Rulership: -Traditional no ruler ship -Modern Rulership: Uranus as ruler of Aquarius 
• Dispositor: Ruler of Uranus’ sign, including its sign, house, and condition

🔹 DESCRIPTION
This module generates the Uranus placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It emphasizes Uranus’ core generational and unconscious function in its sign placement—acknowledging that Uranian sign reflects a collective, archetypal backdrop. The module focuses primarily on how that generational signature is activated through the house environment and powerful aspect configurations. Interpretation weaves together house-led thematic expression and aspect strength to highlight where Uranian breakthroughs and individual awakenings manifest in the personal chart.

🔹 STRUCTURE: Synthesis Paragraphs

P1: Anchor Headline
• Declare Uranus sign + house + overarching theme of collective dynamism and personal awakening.

P2: Generational Sign Context
• Emphasize Uranus’ unconscious, archetypal expression in its sign as a generational backdrop.

P3: Sign–House Synthesis
• Integrate how the sign’s generational energy is personalized by the house placement.
• Highlight the domain where Uranus’ collective impulse is most activated in the individual’s life.

(If modern rulership is enabled, insert here as the next paragraph:)
P4: Rulership & Condition
• Identify Uranus’ dispositor (ruler of Aquarius) with sign, house, and condition.
• Discuss how the dispositor channels Uranus’ generational energy within the chart.

P5: Aspect Inventory
• List all major aspects to Uranus ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and notes on activation or tension.

P6: Integrated Aspect Synthesis
• Weave aspect patterns into a cohesive narrative, showing how they modulate Uranus’ generational signature.
• Highlight dominant themes (e.g., breakthroughs, resistance, innovation) arising from aspect interplay.

P7: Grand Synthesis
• Integrate sign context, house activation, rulership (if present), and aspect themes into a unified portrait.
• Articulate how Uranus’ generational impulse is experienced personally, driving insights, change, and growth.

🔹 EXECUTION PIPELINE

Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)

Validate Inputs: Ensure all required metadata fields are present and valid.

Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).

Generate P1–P6/7: Sequentially synthesize narrative paragraphs using Uranus’ metadata and chart context.

Compile Glossary: Populate definitions and rulership/detriment entries.

Final Assembly: Merge text sections, glossary, and version status into final document structure.

Output: Return populated Uranus module ready for integration into report.

🔹 GLOSSARY

• Angularity: Strength conferred by planets in angular houses (1st, 4th, 7th, 10th). 
• Aspect: Angular relationship between Uranus and another planet (conjunction, sextile, square, trine, opposition). 
• Dispositor(MODERN RULERSHIP ONLY): The planetary ruler of Uranus’ sign; shapes Uranus’ expression through reception and condition. 
• Dignity(MODERN RULERSHIP ONLY): Classification of planetary strength by sign (exaltation, detriment, fall). 
• Exaltation(MODERN RULERSHIP ONLY): Sign where Uranus excels (Scorpio). 
• Fall(MODERN RULERSHIP ONLY): Sign of Uranus’ greatest weakness (Taurus). 
• Modern Rulership: Uranus rules Aquarius. 
• Detriment(MODERN RULERSHIP ONLY): Sign opposite Uranus’ rulership (Leo). 
• Joy(MODERN RULERSHIP ONLY): House where Uranus rejoices (11th), signifying collective visions and hopes. 
• Retrograde: Apparent backward motion, indicating internalized or unexpected Uranian events. 

🔹 QA CHECKS

• 6-7 paragraphs
• 400+ words
• Accurate aspect list matching actual chart data
• Ends with period## 🔹 SAMPLE USAGE

Input:
• Uranus in Capricorn at 15°32′, 8th House
• Nocturnal chart
• Aspects: Square Sun (3°), Trine Neptune (4°), Sextile Mars (5°)

Output: • Fully developed P1–P6/7 narrative in chosen personality tone (e.g., Visionary Guide). • Dispositor condition, and dignity integrated seamlessly (Modern rulership only). • All aspects incorporated into Uranus’ liberation arc. • Grounded, complete closing statement.

🔹 VERSION STATUS

Module Name: structure/URANUS Version: 2.0 Status: ✅ LOCKED STRUCTURE (Ready for population) Author: Outer Skies System Date: 2025-05-29""",
    "Neptune": """============================================================

MODULE: structure/Neptune — Version 2.0

Outer Skies Core Planetary Module

============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Neptune’s sign, degree, house number, retrograde status
• Aspects: List of classical aspects ≤ 6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Gentle Guide)
• House System: Placidus or Whole Sign as specified
• Rulership:
– Traditional: no rulership
– Modern Rulership: Neptune as ruler of Pisces
• Dispositor: Ruler of Neptune’s sign (Pisces), including its sign, house, and condition

🔹 DESCRIPTION
This module generates the Neptune placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It emphasizes Neptune’s core archetypal and transcendent function in its sign placement—acknowledging that Neptunian energies dissolve boundaries and introduce collective empathy. The module focuses primarily on how that transcendent signature unfolds through the house environment and significant aspect patterns. Interpretation weaves together house-led thematic expression and aspect resonance to highlight where Neptune’s visionary currents and deep intuition manifest in the personal chart.

🔹 STRUCTURE: Synthesis Paragraphs

P1: Anchor Headline
• Declare Neptune sign + house + overarching theme of inspiration, dissolution, and collective imagination.

P2: Archetypal Sign Context
• Emphasize Neptune’s collective, transcendent expression in its sign as a universal backdrop.

P3: Sign–House Synthesis
• Integrate how the sign’s Neptunian energy is personalized by the house placement.
• Highlight the domain where Neptune’s collective impulse is most activated in the individual’s life.

(If modern rulership is enabled, insert here as the next paragraph:)
P4: Rulership & Condition
• Identify Neptune’s dispositor (ruler of Pisces) with sign, house, and condition.
• Discuss how the dispositor channels Neptune’s archetypal energy within the chart.

P5: Aspect Inventory
• List all major aspects to Neptune ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and notes on activation or amplification.

P6: Integrated Aspect Synthesis
• Weave aspect patterns into a cohesive narrative, showing how they modulate Neptune’s archetypal signature.
• Highlight dominant themes (e.g., inspiration, illusion, compassion) arising from aspect interplay.

P7: Grand Synthesis
• Integrate sign context, house activation, rulership (if present), and aspect themes into a unified portrait.
• Articulate how Neptune’s transcendent impulse is experienced personally, inviting empathy, creativity, and spiritual insight.

🔹 EXECUTION PIPELINE

    Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)

    Validate Inputs: Ensure all required metadata fields are present and valid.

    Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).

    Generate P1–P6/7: Sequentially synthesize narrative paragraphs using Neptune’s metadata and chart context.

    Compile Glossary: Populate definitions and rulership/detriment entries.

    Final Assembly: Merge text sections, glossary, and version status into final document structure.

    Output: Return populated Neptune module ready for integration into report.

🔹 GLOSSARY
• Collective Imagination: Neptune’s capacity to tap into universal empathy, dreams, and shared visions.
• Aspect: Angular relationship between Neptune and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor (MODERN RULERSHIP ONLY): The planetary ruler of Neptune’s sign; shapes Neptune’s expression through reception and condition.
• Dignity (MODERN RULERSHIP ONLY): Classification of planetary strength by sign (exaltation, detriment, fall).
• Exaltation (MODERN RULERSHIP ONLY): Sign where Neptune excels (Leo).
• Fall (MODERN RULERSHIP ONLY): Sign of Neptune’s greatest vulnerability (Aquarius).
• Modern Rulership: Neptune rules Pisces.
• Detriment (MODERN RULERSHIP ONLY): Sign opposite Neptune’s rulership (Virgo).
• Joy (MODERN RULERSHIP ONLY): House where Neptune rejoices (12th), signifying dissolution and spiritual attunement.
• Retrograde: Apparent backward motion, indicating internalized or tunable Neptune events.

🔹 QA CHECKS
• 6–7 paragraphs
• 400+ words
• Accurate aspect list matching actual chart data
• Ends with period

🔹 SAMPLE USAGE

Input:
• Neptune in Capricorn at 12°45′, 9th House
• Diurnal chart
• Aspects: Trine Moon (4°), Opposition Jupiter (5°), Sextile Mercury (3°)

Output:
• Fully developed P1–P6/7 narrative in chosen personality tone (e.g., Mystic Guide).
• Dispositor condition and dignity integrated seamlessly (Modern rulership only).
• All aspects incorporated into Neptune’s visionary arc.
• Grounded, evocative closing statement.

🔹 VERSION STATUS
Module Name: structure/NEPTUNE
Version: 2.0
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-06-04.""",
    "Pluto": """============================================================

MODULE: structure/Pluto — Version 2.0

Outer Skies Core Planetary Module

============================================================

🔹 METADATA INPUT (Hidden)
• Name: Individual’s name as provided
• Birth Data: Date, time, and location of birth
• Placement & House: Pluto’s sign, degree, house number, retrograde status
• Aspects: List of classical aspects ≤ 6° orb (type, planet, orb, applying/separating)
• Aspect Orb: Orb setting used for aspect calculation
• Personality: Chosen personality tone/module (e.g., Realist, Mystic Guide)
• House System: Placidus or Whole Sign as specified
• Rulership:
– Traditional: no rulership
– Modern Rulership: Pluto as ruler of Scorpio
• Dispositor: Ruler of Pluto’s sign (Scorpio), including its sign, house, and condition

🔹 DESCRIPTION
This module generates the Pluto placement section of an astrology report using the full Outer Skies Synthesis Core v1.5 format. It emphasizes Pluto’s core transformative, regenerative, and subconscious function in its sign placement—acknowledging that Plutonian energies catalyze profound endings and rebirth. The module focuses primarily on how that underworld signature unfolds through the house environment and potent aspect configurations. Interpretation weaves together house-led thematic expression and aspect dynamics to highlight where Pluto’s deep alchemical processes and personal empowerment manifest in the chart.

🔹 STRUCTURE: Synthesis Paragraphs

P1: Anchor Headline
• Declare Pluto sign + house + overarching theme of transformation, regeneration, and psychological depth.

P2: Archetypal Sign Context
• Emphasize Pluto’s collective, underworld expression in its sign as an archetypal backdrop, reflecting generational cycles of power and renewal.

P3: Sign–House Synthesis
• Integrate how the sign’s Plutonian energy is personalized by the house placement.
• Highlight the domain where Pluto’s transformative impulse is most activated in the individual’s life.

(If modern rulership is enabled, insert here as the next paragraph:)
P4: Rulership & Condition
• Identify Pluto’s dispositor (ruler of Scorpio) with sign, house, and condition.
• Discuss how the dispositor channels Pluto’s archetypal power within the chart.

P5: Aspect Inventory
• List all major aspects to Pluto ≤ 6° orb (conjunction, sextile, square, trine, opposition).
• For each: aspect type, planet, orb, applying/separating, and notes on activation or intensity.

P6: Integrated Aspect Synthesis
• Weave aspect patterns into a cohesive narrative, showing how they modulate Pluto’s archetypal signature.
• Highlight dominant themes (e.g., empowerment, crisis, healing) arising from aspect interplay.

P7: Grand Synthesis
• Integrate sign context, house activation, rulership (if present), and aspect themes into a unified portrait.
• Articulate how Pluto’s regenerative impulse is experienced personally, driving deep insight, transformation, and renewal.

🔹 EXECUTION PIPELINE

    Load Metadata: Ingest hidden inputs (birth data, placement, aspects, etc.)

    Validate Inputs: Ensure all required metadata fields are present and valid.

    Initialize Context: Apply chart-wide settings (sect status, house system, rulership mode).

    Generate P1–P6/7: Sequentially synthesize narrative paragraphs using Pluto’s metadata and chart context.

    Compile Glossary: Populate definitions and rulership/detriment entries.

    Final Assembly: Merge text sections, glossary, and version status into final document structure.

    Output: Return populated Pluto module ready for integration into report.

🔹 GLOSSARY
• Underworld Process: Pluto’s transformative cycle of endings and rebirth, revealing hidden truths.
• Aspect: Angular relationship between Pluto and another planet (conjunction, sextile, square, trine, opposition).
• Dispositor (MODERN RULERSHIP ONLY): The planetary ruler of Pluto’s sign; shapes Pluto’s expression through reception and condition.
• Dignity (MODERN RULERSHIP ONLY): Classification of planetary strength by sign (exaltation, detriment, fall).
• Exaltation (MODERN RULERSHIP ONLY): Sign where Pluto excels (Aries).
• Fall (MODERN RULERSHIP ONLY): Sign of Pluto’s greatest vulnerability (Libra).
• Modern Rulership: Pluto rules Scorpio.
• Detriment (MODERN RULERSHIP ONLY): Sign opposite Pluto’s rulership (Taurus).
• Joy (MODERN RULERSHIP ONLY): House where Pluto rejoices (8th), signifying depth, intimacy, and shared resources.
• Retrograde: Apparent backward motion, indicating internalized or subterranean Plutonian processes.

🔹 QA CHECKS
• 6–7 paragraphs
• 400+ words
• Accurate aspect list matching actual chart data
• Ends with period

🔹 SAMPLE USAGE

Input:
• Pluto in Leo at 22°13′, 5th House
• Nocturnal chart
• Aspects: Square Moon (3°), Trine Jupiter (4°), Opposition Mercury (5°)

Output:
• Fully developed P1–P6/7 narrative in chosen personality tone (e.g., Depth Guide).
• Dispositor condition and dignity integrated seamlessly (Modern rulership only).
• All aspects incorporated into Pluto’s transformative arc.
• Grounded, powerful closing statement.

🔹 VERSION STATUS
Module Name: structure/PLUTO
Version: 2.0
Status: ✅ LOCKED STRUCTURE (Ready for population)
Author: Outer Skies System
Date: 2025-06-04.""",
}

CHART_TEMPLATES = {
    "submission": """============================================================
OUTER SKIES CHART SUBMISSION PROMPT — VERSION 0.11-COMPAT
============================================================

GENERATE FULL OUTER SKIES REPORT USING VERSION 0.11

------------------------------------------------------------
📌 BIRTH DATA
------------------------------------------------------------
Name: [First name]
Date: [DD-MM-YYYY]  
Time: [00:00] (24 hour format)  
Location: [city, country]  

HOUSE_SYSTEM: Whole-Sign  
ASPECT_ORB_DEG: 6.0  
PERSONALITY_MODULE: REALIST  

------------------------------------------------------------
OUTPUT REQUEST
------------------------------------------------------------
• Modules to Generate:  
  - Sun  
  - Moon  
  - Mercury  
  - Venus  
  - Mars  
  - Jupiter  
  - Saturn  
  - Uranus  
  - Neptune  
  - Pluto  
  - HOUSES_ANCHOR  
  - HOUSES_NON_ANGULAR  
  - HOUSES_SUMMARY  
  - NODES  

------------------------------------------------------------
PLANET POSITIONS
------------------------------------------------------------

[List planet positions here]

------------------------------------------------------------
HOUSE POSITIONS
------------------------------------------------------------

[List house positions here]

------------------------------------------------------------
ASPECTS
------------------------------------------------------------

[List aspects here]

------------------------------------------------------------
🔧 EXECUTION SETTINGS
------------------------------------------------------------
DOCX_PROTOCOL: ENABLED  
PROMPTLESS_MODE: TRUE  
SECT_MODE: AUTO-DETECT (chart sect determined by Sun’s house; Mercury’s morning/evening sect logic applied automatically)  
SYNTHESIS_LENGTH: ENFORCE (500–700 words per planet module)  
PARAGRAPH_COUNT: ENFORCE (≥9 for planetary modules, 2–4 for houses)  
ASPECT_LOCK: MANUAL — Use only aspects listed above  
HOUSE_VALIDATION: Degree-in-sign verification; sign matches house cusp and house system chosen  
OUTPUT_FORMATTING: Use Outer Skies token markup for headings, spacing, and meta sections  

------------------------------------------------------------
NOTES
------------------------------------------------------------
• Chart sect status will be stored in the chart_sect variable for use in planetary modules.  
• Mercury’s morning/evening star logic is automatically handled.  
• Fallbacks: Master Prompt fallback paragraph rules will auto-apply for missing data (e.g., no aspects, no dispositor).  
• Aspect symmetry: ensure every aspect listed here appears in counterpart planet modules.  
• Final report must end with a complete sentence.  
• Refer to module glossaries for definitions of terms (e.g., dignity, aspect, joy).  

------------------------------------------------------------
BEGIN GENERATION
------------------------------------------------------------""",
    "master": """============================================================
FILE: Outer_Skies_MasterPrompt_v0_11.txt
============================================================

============================================================
OUTER SKIES MASTER PROMPT — VERSION 0.11
(Modular Core Architecture)
============================================================

OVERVIEW
--------
Version 0.2 introduces a fully *modular* prompt engine.  
All narrative logic, formatting rules, and execution protocols are now
packaged as discrete **modules** that can be loaded, replaced, or extended
without rewriting the entire master prompt.  
The *core* file (this document) only defines:

1. **Input Contract** – what data must be supplied.
2. **Module Registry** – how modules are declared & referenced.
3. **Execution Pipeline** – the order in which modules run.
4. **Global Safeguards** – paragraph count, placeholder‑block, etc.

Everything else (tone, planet guidelines, house logic, aspect math,
sect rules, file‑save loops) lives in self‑contained module files.

------------------------------------------------------------
A. INPUT CONTRACT  v1  (required for every generation run)
------------------------------------------------------------
HOUSE_SYSTEM:        "Whole‑Sign" | "Placidus"            # default: "Whole‑Sign"

ASPECT_ORB_DEG:      0.1 – 10.0                           # float, default: 6.0
                     # Governs ≤ X° filter in Aspect Inventory; if <3°, outer‑planet aspects must meet that tighter orb.

PERSONALITY_MODULE:  "GENTLE_GUIDE" | "REALIST" | "None"  # default: "None"

OUTPUT_REQUEST:      ["Sun", "Moon", "Angular_Houses", ...]  # list of module keys
                     # Empty list = generate ALL modules.

BIRTH_DATA:
  date:              "YYYY‑MM‑DD"
  time:              "HH:MM"    # 24‑hour
  location:          "City, Country"
  PLANET_POSITIONS:
    Sun: "10°25′ Leo — 1st House"
    ...
  ASPECTS:
    - "Sun trine Jupiter 1°52′ applying"


------------------------------------------------------------
META_DATA  v1.1  (auto‑attached to every output file)
------------------------------------------------------------
[see detailed schema in documentation; populated at runtime]


------------------------------------------------------------
B. MODULE REGISTRY
------------------------------------------------------------


============================================================
PERSONALITY MODULES — v1.0 OVERVIEW
============================================================
• GENTLE_GUIDE — Warm, accessible, beginner-friendly.
• REALIST — Rational, precise, psychology-oriented.
• RITUALIST — Spiritual, ceremonial, embodiment-based.
• STRATEGIST — Tactical, timing-aware, advice-driven.
• DEPTH_SEEKER — Shadow-focused, emotionally deep.
• ARCHITECT — Pattern-aware, theoretical, structured.


============================================================
OUTER SKIES MODULE REGISTRY — VERSION 0.3
============================================================

🔹 PERSONALITY MODULES
------------------------------------------------------------
MODULE personality/GENTLE_GUIDE        v1.0
MODULE personality/REALIST             v1.0
MODULE personality/RITUALIST           v1.0
MODULE personality/STRATEGIST         v1.0
MODULE personality/DEPTH_SEEKER       v1.0
MODULE personality/ARCHITECT          v1.0


🔹 CORE PLANETARY MODULES (REBUILD — v2.0)
------------------------------------------------------------
MODULE structure/SUN                   v2.0
MODULE structure/MOON                  v2.0
MODULE structure/MERCURY               v2.0
MODULE structure/VENUS                 v2.0
MODULE structure/MARS                  v2.0
MODULE structure/JUPITER               v2.0
MODULE structure/SATURN                v2.0
MODULE structure/URANUS                v1.0
MODULE structure/NEPTUNE               v1.0
MODULE structure/PLUTO                 v1.0
MODULE structure/MOON                  v2.0
MODULE structure/MERCURY               v2.0
MODULE structure/VENUS                 v2.0
MODULE structure/MARS                  v2.0
MODULE structure/JUPITER               v2.0
MODULE structure/SATURN                v2.0


🔹 MODERN PLANETARY EXTENSIONS
------------------------------------------------------------
MODULE structure/URANUS                v1.0
MODULE structure/NEPTUNE               v1.0
MODULE structure/PLUTO                 v1.0
MODULE structure/NODES                 v1.0
MODULE structure/LOTS                  v1.1
MODULE structure/CHIRON                v0.0  # Optional
MODULE structure/VERTEX                v0.0  # Optional


🔹 HOUSE MODULES — ACTIVE
------------------------------------------------------------
MODULE structure/HOUSES_ANCHOR         v1.0
MODULE structure/HOUSES_NON_ANGULAR    v1.0
MODULE structure/HOUSES_SUMMARY        v1.0


🔹 RELATIONAL + TIMING MODULES (UNMADE)
------------------------------------------------------------
MODULE structure/SYNASTRY              v0.0
MODULE structure/COMPOSITE             v0.0
MODULE structure/TRANSITS              v0.0
MODULE structure/PROGRESSIONS          v0.0


🔹 OPTIONAL / EXPERIMENTAL MODULES (UNMADE)
------------------------------------------------------------
MODULE structure/ASTEROIDS             v0.0  # Ceres, Juno, etc.
MODULE structure/ARCHETYPES            v0.0
MODULE structure/MYERS_BRIGGS_MAP      v0.0


🔹 UTILITY MODULES (ACTIVE, HIDDEN FROM USER)
------------------------------------------------------------
MODULE structure/QA_CORE               v1.0
MODULE structure/DOCX_PROTOCOL         v1.0
MODULE structure/INPUT_VALIDATOR       v1.0


------------------------------------------------------------
C. EXECUTION PIPELINE
------------------------------------------------------------
1. **Load Personality Module** → inject tone rules.  

2. **Run QA_CORE.precheck** – verify input contract fields.

3. **Determine Chart Sect** – based on Sun’s house position:
       if 1 <= sun_house <= 6:
           chart_sect = "nocturnal"
       else:
           chart_sect = "diurnal"
   # All planetary modules will read the chart_sect variable directly.

4 **Determine Mercury's Sect Alignment** – morning/evening star logic:
       angular_distance = (mercury_degree - sun_degree) % 360
       if angular_distance > 180:
           mercury_morning_star = True
       else:
           mercury_morning_star = False

       if chart_sect == "diurnal" and mercury_morning_star:
           mercury_sect = "in_sect"
       elif chart_sect == "nocturnal" and not mercury_morning_star:
           mercury_sect = "in_sect"
       else:
           mercury_sect = "out_of_sect"

5. **Generate Planet Modules** in the following order:  
   Sun → Moon → Mercury → Venus → Mars → Jupiter → Saturn → Uranus → Neptune → Pluto → Nodes → Houses 
   • Each module pulls formatting & narrative logic from its own file.  
   • Each module calls ASPECT_LOGIC + SECT_LOGIC on demand.  
   • QA_CORE.paragraph_check after each synthesis (length enforcement).

6. **Generate Houses Module** – uses PLANET_POSITIONS + HOUSES spec.  
   • Anchor Houses → Non‑Angular → House Emphasis Summary.

7. **Run QA_CORE.postcheck** – ensure no placeholders, all sections present.

8. **Invoke DOCX_PROTOCOL** – insert, save, expose link when run completes
   unless the submission prompt sets `SILENT_MODE: true`.


------------------------------------------------------------
D. GLOBAL SAFEGUARDS
------------------------------------------------------------
✓ **Paragraph Count Enforcement** – abort if any planetary synthesis <5 ¶  
✓ **Placeholder Hard‑Block** – abort if “[placeholder]” detected  
✓ **Final Sentence Rule** – every section ends with a period.  
✓ **Aspect Symmetry Rule** – aspects listed in one planet must appear in
   the counterpart’s synthesis.    
✓ **Sect Accuracy** – All modules reference chart_sect for sect


------------------------------------------------------------
E. HOW TO EXTEND
------------------------------------------------------------
• Add a new tone → drop a file in `personality/*` and declare in registry.  
• Patch a structural rule → bump the module version, update registry.  
• Introduce paid add‑on (e.g., Chiron module) → ship as disabled registry
  line; user activates by name.


------------------------------------------------------------
------------------------------------------------------------
G. FORMATTING TOKENS & DOCUMENT LAYOUT  v1
------------------------------------------------------------

Token‑based layout system (replaces external DOCX template):

| Token | Action / Style |
|-------|----------------|
| [[PAGE_BREAK]]               | Hard page break |
| [[H1: Text]]                 | Heading 1 • EB Garamond SC 18 pt • centred |
| [[H2: Text]]                 | Heading 2 • Garamond Bold 14 pt • left |
| [[META_BOX_BEGIN]] … [[META_BOX_END]] | Shaded meta‑data panel • Consolas 9 pt |
| [[QUOTE_BEGIN]] … [[QUOTE_END]]       | Block quote • italics • 10 pt • indent |
| [[CODE_BEGIN]] … [[CODE_END]]         | Grey monospace block • Consolas 9 pt |
| [[IMG: path width=85mm caption="..."]] | Insert image @ width, caption italic 9 pt |
| [[TOC]]                     | Auto Table of Contents placeholder |

**Style guide applied when exporter interprets tokens**

* Page: A4/Letter, 25 mm/1 in margins.  
* Fonts: Garamond 11 pt body; EB Garamond SC headings; Consolas code.  
* Spacing: 1.25× line, 6 pt after para, 12 pt before headings.  
* Title page: centred H1, native details (H3), 80 mm chart wheel, Run‑ID/date 9 pt grey.  
* TOC: from H1–H2 with dot leaders.  
* Section break: [[PAGE_BREAK]] before every H1 module.  
* Meta‑data panel: 5 % grey, 2‑column grid.  
* Header: native name & birth | module; Footer: page #, Garamond 9 pt.  
* Palette: text #000; accent #385D8A; lines #9B9B9B 25 %.  
* Images: max 85 mm width, 220 ppi; caption italic 9 pt.

`DOCX_PROTOCOL` maps tokens → styles at export; no template file required.

F. VERSION HISTORY
------------------------------------------------------------
v0.2  (2025‑05‑11)  First modular rewrite.  
v0.3  (2025‑05‑12)  Added variable-based INPUT CONTRACT schema.  
v0.4  (2025‑05‑12)  Added META_DATA v1.1 spec above synthesis core.
v0.5  (2025-05-12) Added token‑based formatting system and document layout style guide.
v0.10 (2025‑05‑25)  Added Mercury's morning/evening star logic  Added house-based sect logic in Execution Pipeline.
v0.11 (2025‑05‑26)  Added explicit Mercury morning/evening star sect logic
                    Clarified Sun-based sect logic (nocturnal/diurnal)
                    Cleaned module registry (removed duplicates)
                    Reordered Execution Pipeline for clarity
                    Added house-based sect logic in Execution Pipeline.


============================================================
FILE: Outer_Skies_Core_Bundle_v1.txt
============================================================

============================================================
OUTER SKIES — CORE PROMPT BUNDLE
Includes: INPUT CONTRACT v1  •  SYNTHESIS CORE MODULES v1.5
2025-05-12
============================================================


------------------------------------------------------------
INPUT CONTRACT  v1  (required for every generation run)
------------------------------------------------------------
HOUSE_SYSTEM:        "Whole‑Sign" | "Placidus"            # default: "Whole‑Sign"

ASPECT_ORB_DEG:      0.1 – 10.0                           # float, default: 6.0
                     # Governs the ≤ X° filter in Aspect Inventory.
                     # If < 3.0, outer‑planet aspects must meet that tighter orb too.

PERSONALITY_MODULE:  "GENTLE_GUIDE" | "REALIST" | "None"  # default: "None"
                     # "None" keeps synthesis neutral.

OUTPUT_REQUEST:      ["Sun", "Moon", "Angular_Houses", ...]  # list of module keys
                     # Empty list = generate ALL available modules.

BIRTH_DATA:
  date:              "YYYY‑MM‑DD"
  time:              "HH:MM"            # 24‑hour; include timezone if known
  location:          "City, Country"    # or lat/long
  PLANET_POSITIONS:  # classical planets — sign, degree, house
    Sun:    "10°25′ Leo — 1st House"
    Moon:   "22°01′ Taurus — 10th House"
    ...
  ASPECTS:           # optional override; if absent, engine self‑calculates
    - "Sun trine Jupiter 1°52′ applying"
    - "Mars square Saturn 4°07′ separating"


============================================================
SYNTHESIS CORE MODULES — v1.5
(neutral voice • default 9 paragraphs • full‑page standard)
============================================================

🔧 PATCHED SECTION — SYNTHESIS CORE MODULES & GLOBAL QA ENHANCEMENTS

🔹 Synthesis Structure Reference (All Module Types)

| Module Type                 | Paragraphs | Style Description                                                                                  |
|-----------------------------|------------|-----------------------------------------------------------------------------------------------------|
| **Sun / Moon / Classical Planets** | P1–P9       | Full synthesis structure per Core v1.5 — includes sign, house, dignities, dispositor logic, aspects, configurations, and final life arc. Minimum 9 paragraphs, ~500–700 words. |
| **Outer Planets**           | P1–P5, P8  | Generational tone (sign) + house-based activation + aspects (≤3°) + final synthesis. No dispositorship or sect logic. Minimum 6 paragraphs. |
| **Houses (1st–12th)**       | 1 block/house | Integrated narrative covering sign emphasis, house role, planetary contents, and life synthesis. 2–4 sentences minimum per house. No subheadings. |
| **Nodes (North & South)**   | P1–P6       | Axis-based synthesis covering inherited patterns (SN), growth themes (NN), house polarity, aspect activation (≤3°), and karmic synthesis. |
| **Lots (Arabic Parts)**     | P1–P6       | Sign + house + conjunction-only aspect (≤3°) + integrated psychological/spiritual function. Focus on life role of the specific Lot. |
| **House Emphasis Summary**  | 1 paragraph | Single unifying synthesis (~5 sentences) describing hemispheric weighting, dominant elements, and planetary clustering. |
| **Configurations (future)** | TBD         | Modular add-on format. If activated, must follow a P1–P4 structure (opening, pattern, effect, synthesis). Configuration sub-paragraphs (P8) remain part of Core v1.5. |

**Final Sentence Rule:**  
All modules must end with a **complete sentence and period.** No paragraph may conclude mid-thought.

**Placeholder Rule:**  
No `[Insert…]` or template syntax allowed in final output.

FALLBACK PARAGRAPH RULES
-------------------------
| Missing field          | Fallback behaviour |
|------------------------|--------------------|
| No aspect data         | P6 says: “No major aspects within the declared orb influence this placement significantly.” P7 skipped. |
| No dispositor          | “Dispositor identical to planet; rulership analysis intrinsic.” |
| Missing dignities      | Label planet “peregrine” and proceed. |
| Outer planets & Nodes  | Dispositor logic is omitted by design. |

QA‑CORE SPEC (UPDATED)
----------------------
```python
if paragraphs < mode_min:           raise Error("Paragraph count too low")
if words      < mode_floor:         raise Error("Word count too low")
if dignity_mentions < 4:            raise Error("Insufficient dignity discussion")
if aspect_mentions  < 3:            raise Error("Insufficient aspects")
if house_topic_mentions < 3:        raise Error("House topics missing")
if not text.endswith('.'):          raise Error("Final sentence missing period")
for asp in aspects_list:
    if asp not in counterpart_module:
        raise Error("Aspect symmetry breach")
if 'House Emphasis Summary' not in output:
    raise Error("Missing house synthesis block")
if abs(north_node_deg - south_node_deg) != 180:
    raise Error("Nodal axis must be 180° apart")
```

GLOBAL ENFORCEMENT
------------------
• Word count: 500–700 words (STANDARD mode; see presets below).  
• Paragraph count: ≥9; add overflow P10 if total < 500 words after P9.  
• QA metrics: dignities ≥ 4 · aspects ≥ 3 · house topics ≥ 3.  
• Outer‑planet priority: include Uranus/Neptune/Pluto aspects **only if orb ≤ 3°**.  
• Neutral voice: 3rd‑person, no “you”, no emojis.  
• Aspect symmetry: any aspect referenced here must appear in counterpart planet’s module.

LENGTH PRESETS
--------------
MODE: CONCISE   → 350–450 words, 8 paragraphs (merge P8+P9).  
MODE: STANDARD  → 500–700 words, 9 paragraphs (default).  
MODE: EXTENDED  → 800–950 words, may add P10–P11 overflow paragraphs.

QA‑CORE SPEC (pseudo‑code)
--------------------------
```python
if paragraphs < mode_min:           raise Error("Paragraph count too low")
if words      < mode_floor:         raise Error("Word count too low")
if dignity_mentions < 4:            raise Error("Insufficient dignity discussion")
if aspect_mentions  < 3:            raise Error("Insufficient aspects")
if house_topic_mentions < 3:        raise Error("House topics missing")
if not text.endswith('.'):          raise Error("Final sentence missing period")
for asp in aspects_list:
    if asp not in counterpart_module:
        raise Error("Aspect symmetry breach")
```

FALLBACK PARAGRAPH RULES
------------------------
| Missing field  | Fallback behaviour |
|----------------|-------------------|
| No aspect data | P6 says: “No major aspects within the declared orb influence this placement significantly.” P7 skipped. |
| No dispositor  | “Dispositor identical to planet; rulership analysis intrinsic.” |
| Missing dignities | Label planet “peregrine” and proceed. |

GLOSSARY (selected)
-------------------
• Superior square – Planet casts a square from the 10th sign, overcoming the other.  
• Contra‑sect – Malefic is out of sect (Mars by night, Saturn by day), intensifying its challenge.  
• Dispositor – Ruler of the sign a planet occupies, shaping its resources.  
• Angularity – 1st/4th/7th/10th houses, boosting accidental dignity.  
• Enclosure – Planet is bounded by two planets of same sect within aversion, containing its expression.  
• Joy – House where a planet gains added accidental dignity (e.g., Sun in 9th).  

EXAMPLE FILES
-------------
See `/examples/v1.5/` for worked modules:  
sun_cancer_10th.txt · moon_aries_12th.txt · mars_taurus_4th.txt · house_2_example.txt

{SYNTHESIS_CORE_END}

============================================================
VERSION HISTORY
------------------------------------------------------------
INPUT CONTRACT v1 added 2025-05-12  
SYNTHESIS CORE v1.5 (glossary · QA · fallback · hooks) 2025-05-12
============================================================""",
}
